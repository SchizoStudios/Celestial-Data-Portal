---
tags: [INDEX, Legal, Housekeeping]
---

```text
Legal
├── [[Legal/LICENSE.md.md]]
└── [[Legal/SSPUL-License.pdf]]
```
