---
tags: [INDEX, Templates, Housekeeping]
---

```text
Templates
├── [[Templates/Aspects Template.md]]
├── [[Templates/Astrology House Codex Template.md]]
├── [[Templates/Celestial Bodies and Calculation Points ReadMe Template.md]]
├── [[Templates/Celestial Body Definition Template.md]]
├── [[Templates/Fixed Star Building Blocks Template.md]]
├── [[Templates/Planet-Body Template.md]]
├── [[Templates/Word Definition Template.md]]
└── [[Templates/Zodiac Sign Template.md]]
```
