---
tags: [INDEX, Synastry Chart, Housekeeping]
---

```text
Analysis Guidelines/Synastry Chart
├── [[Analysis Guidelines/Synastry Chart/Comprehensive]]
│   ├── [[Analysis Guidelines/Synastry Chart/Comprehensive/Analysis Instructions.md]]
│   └── [[Analysis Guidelines/Synastry Chart/Comprehensive/Overview.md]]
├── [[Analysis Guidelines/Synastry Chart/Emotional]]
│   ├── [[Analysis Guidelines/Synastry Chart/Emotional/Analysis Instructions.md]]
│   └── [[Analysis Guidelines/Synastry Chart/Emotional/Overview.md]]
├── [[Analysis Guidelines/Synastry Chart/Overview.md]]
├── [[Analysis Guidelines/Synastry Chart/Soul-Path]]
│   ├── [[Analysis Guidelines/Synastry Chart/Soul-Path/Analysis Instructions.md]]
│   └── [[Analysis Guidelines/Synastry Chart/Soul-Path/Overview.md]]
└── [[Analysis Guidelines/Synastry Chart/Spiritual]]
    ├── [[Analysis Guidelines/Synastry Chart/Spiritual/Analysis Instructions.md]]
    └── [[Analysis Guidelines/Synastry Chart/Spiritual/Overview.md]]
```
