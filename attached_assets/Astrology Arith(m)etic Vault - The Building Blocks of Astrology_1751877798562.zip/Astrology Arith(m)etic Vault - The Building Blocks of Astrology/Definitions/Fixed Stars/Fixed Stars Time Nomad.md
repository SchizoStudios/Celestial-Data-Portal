
1. Alcyone (the Pleiades)
2. Aldebaran
3. Algol
4. Algorab
5. Alkaid (Benetnash)
6. Alphecca
7. Antares
8. Arcturus
9. Capella
10. Deneb Algedi
11. Procyon
12. Regulus
13. Sirius
14. Spica
15. Vega (Wega)
16. Aculeus (Butterfly Cluster)
17. Acumen (Ptolemy Cluster)
18. Andromeda Galaxy
19. Copula (Whirlpool Galaxy)
20. Facies
21. Praesepe (Beehive Cluster)
22. Spiculum (Lagoon Nebula)
23. Achernar
24. Acrux
25. Acubens
26. Adhafera
27. Agena (Hadar)
28. Ain (Ain Hyadum)
29. Al Hecka
30. Al Jabhah
31. Al Pherg
32. Albireo
33. Algenib
34. Algenubi
35. Alhena
36. Almach
37. Alnilam
38. Alphard
39. Alpheratz
40. Altair
41. Armus
42. Ascella
43. Asellus Australis
44. Asellus Borealis
45. Baten Kaitos
46. Bellatrix
47. Betelgeuse
48. Bungula
49. Canopus
50. Castor
51. Castra
52. Dabih
53. Deneb Adige
54. Denebola
55. Dheneb (Deneb Al Okab)
56. Difda
57. Dorsum
58. El Nath
59. Enif
60. Fomalhaut
61. Gienah
62. Hamal
63. Markab
64. Menkar
65. Mintaka
66. Mirach
67. Mirzam
68. Phecda
69. Polaris
70. Pollux
71. Ras Alhague
72. Rigel
73. Sabik
74. Schedar
75. Shaula
76. Sheliak
77. Sualocin
78. Suhail
79. Unukalhai
80. Zosma
81. Zubenelgenubi
82. Zubeneschamali
83. Alkes
84. Algiedi
85. Alderamin
86. Alrescha
87. Menkent
88. Nihal
89. Sadalmelik
90. Sadalsuud
91. Sargas
92. Tarazed
93. Tejat Posterior
94. Thuban
95. Wasat
96. Yed Prior
97. Yed Posterior
98. Kaus Australis
99. Kaus Borealis
100. Kaus Media
101. Lesath
102. Rasalhague
103. Rasalgethi
104. Alcyoneus
105. Aludra
106. Ankaa
107. Mirfak

#fixedstars #Housekeeping 