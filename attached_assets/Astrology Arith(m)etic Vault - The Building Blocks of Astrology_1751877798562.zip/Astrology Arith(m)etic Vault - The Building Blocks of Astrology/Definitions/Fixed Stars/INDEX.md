```text
Definitions/Fixed Stars
├── [[Definitions/Fixed Stars/Alcyone.md]]
├── [[Definitions/Fixed Stars/Aldebaran.md]]
├── [[Definitions/Fixed Stars/Algol.md]]
├── [[Definitions/Fixed Stars/Alhena.md]]
├── [[Definitions/Fixed Stars/Alpheratz.md]]
├── [[Definitions/Fixed Stars/Betelgeuse.md]]
├── [[Definitions/Fixed Stars/Capella.md]]
├── [[Definitions/Fixed Stars/Menkalinan.md]]
├── [[Definitions/Fixed Stars/Metaphysical Codex of Fixed Stars.md]]
├── [[Definitions/Fixed Stars/Metaphysical Codex of Fixed Stars.pdf]]
├── [[Definitions/Fixed Stars/Polaris.md]]
├── [[Definitions/Fixed Stars/Regulus.md]]
└── [[Definitions/Fixed Stars/Sirius.md]]
```
