---
tags: [INDEX, Houses, Housekeeping]
---

```text
Definitions/Houses
├── [[Definitions/Houses/10th House.md]]
├── [[Definitions/Houses/11th House.md]]
├── [[Definitions/Houses/12th House.md]]
├── [[Definitions/Houses/1st House.md]]
├── [[Definitions/Houses/2nd House.md]]
├── [[Definitions/Houses/3rd House.md]]
├── [[Definitions/Houses/4th House.md]]
├── [[Definitions/Houses/5th House.md]]
├── [[Definitions/Houses/6th House.md]]
├── [[Definitions/Houses/7th House.md]]
├── [[Definitions/Houses/8th House.md]]
└── [[Definitions/Houses/9th House.md]]
```
