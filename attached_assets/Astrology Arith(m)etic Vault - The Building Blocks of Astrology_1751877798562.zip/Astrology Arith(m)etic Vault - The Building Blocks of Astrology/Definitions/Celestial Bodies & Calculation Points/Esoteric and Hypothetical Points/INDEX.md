---
tags: [INDEX, Esoteric and Hypothetical Points, Housekeeping]
---

```text
Definitions/Celestial Bodies & Calculation Points/Esoteric and Hypothetical Points
├── [[Definitions/Celestial Bodies & Calculation Points/Esoteric and Hypothetical Points/Admetos – The Anchor of Endurance.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Esoteric and Hypothetical Points/Apollon – The Ray of Expansive Vision.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Esoteric and Hypothetical Points/Cupido – The Spark of Archetypal Union.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Esoteric and Hypothetical Points/Hades – The Depths of Ancestral Memory.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Esoteric and Hypothetical Points/Kronos – The Law of Time’s Structure.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Esoteric and Hypothetical Points/Persephone – The Bloom of Underworld Passage.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Esoteric and Hypothetical Points/Poseidon – The Tide of Mystical Truth.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Esoteric and Hypothetical Points/README.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Esoteric and Hypothetical Points/Transpluto – The Blade of Perfection.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Esoteric and Hypothetical Points/Vulcan – The Forge of Inner Steel.md]]
└── [[Definitions/Celestial Bodies & Calculation Points/Esoteric and Hypothetical Points/Zeus – The Bolt of Creative Command.md]]
```
