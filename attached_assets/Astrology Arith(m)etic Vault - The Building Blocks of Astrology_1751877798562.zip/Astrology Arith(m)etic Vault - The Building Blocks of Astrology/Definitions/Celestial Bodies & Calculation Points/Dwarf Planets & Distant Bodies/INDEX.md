---
tags: [INDEX, Dwarf Planets & Distant Bodies, Housekeeping]
---

```text
Definitions/Celestial Bodies & Calculation Points/Dwarf Planets & Distant Bodies
├── [[Definitions/Celestial Bodies & Calculation Points/Dwarf Planets & Distant Bodies/Gonggong – The Tidal Lord of Unleashed Power.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Dwarf Planets & Distant Bodies/Ixion – The Transgressor of Sacred Trust.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Dwarf Planets & Distant Bodies/Orcus – The Keeper of Oaths and Consequence.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Dwarf Planets & Distant Bodies/Quaoar – The Harmonic Architect of Form.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Dwarf Planets & Distant Bodies/README.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Dwarf Planets & Distant Bodies/Sedna – The Deep Time Siren.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Dwarf Planets & Distant Bodies/Varuna – The Cosmic Arbiter of Moral Law.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Dwarf Planets & Distant Bodies/⚳ Ceres – The Keeper of Nourishment and Loss.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Dwarf Planets & Distant Bodies/⚴ Eris The Disruptor of False Harmony.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Dwarf Planets & Distant Bodies/⚵ Makemake – The Architect of Wild Order.md]]
└── [[Definitions/Celestial Bodies & Calculation Points/Dwarf Planets & Distant Bodies/⚶ Haumea – The Shaper of Sacred Cycles.md]]
```
