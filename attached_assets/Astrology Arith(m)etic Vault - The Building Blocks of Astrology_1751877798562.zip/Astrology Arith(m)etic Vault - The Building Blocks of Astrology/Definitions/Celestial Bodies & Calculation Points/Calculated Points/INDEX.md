---
tags: [INDEX, Calculated Points, Housekeeping]
---

```text
Definitions/Celestial Bodies & Calculation Points/Calculated Points
├── [[Definitions/Celestial Bodies & Calculation Points/Calculated Points/Anti-Vertex.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Calculated Points/Ascendant.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Calculated Points/Black Moon Lilith.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Calculated Points/Descendant.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Calculated Points/Imum Coeli.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Calculated Points/Midheaven.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Calculated Points/North Node.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Calculated Points/Part of Fortune.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Calculated Points/Part of Spirit.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Calculated Points/README.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Calculated Points/South Node.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Calculated Points/Vertex.md]]
└── [[Definitions/Celestial Bodies & Calculation Points/Calculated Points/White Moon Selene.md]]
```
