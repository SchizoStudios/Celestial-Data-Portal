---
tags: [INDEX, Special Points in Advanced Systems, Housekeeping]
---

```text
Definitions/Celestial Bodies & Calculation Points/Special Points in Advanced Systems
├── [[Definitions/Celestial Bodies & Calculation Points/Special Points in Advanced Systems/Earth (Heliocentric).md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Special Points in Advanced Systems/Galactic Center.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Special Points in Advanced Systems/Great Attractor.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Special Points in Advanced Systems/Lunar Apogee (Black Moon).md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Special Points in Advanced Systems/Lunar Perigree.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Special Points in Advanced Systems/README.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Special Points in Advanced Systems/Shapley Attractor.md]]
├── [[Definitions/Celestial Bodies & Calculation Points/Special Points in Advanced Systems/Sun-Moon Midpoint.md]]
└── [[Definitions/Celestial Bodies & Calculation Points/Special Points in Advanced Systems/Super Galactic Center.md]]
```
