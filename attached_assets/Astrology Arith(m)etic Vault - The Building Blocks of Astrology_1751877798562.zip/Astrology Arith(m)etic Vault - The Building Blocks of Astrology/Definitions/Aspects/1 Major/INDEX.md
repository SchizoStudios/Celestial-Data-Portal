---
tags: [INDEX, 1 Major, Housekeeping]
---

```text
Definitions/Aspects/1 Major
├── [[Definitions/Aspects/1 Major/Conjunction.md]]
├── [[Definitions/Aspects/1 Major/Opposition.md]]
├── [[Definitions/Aspects/1 Major/README.md]]
├── [[Definitions/Aspects/1 Major/Sextile.md]]
├── [[Definitions/Aspects/1 Major/Square.md]]
└── [[Definitions/Aspects/1 Major/Trine.md]]
```
