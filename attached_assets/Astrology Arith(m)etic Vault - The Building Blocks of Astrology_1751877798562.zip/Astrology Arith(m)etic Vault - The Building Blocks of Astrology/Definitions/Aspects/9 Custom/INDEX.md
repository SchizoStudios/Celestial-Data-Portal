---
tags: [INDEX, 9 Custom, Housekeeping]
---

```text
Definitions/Aspects/9 Custom
├── [[Definitions/Aspects/9 Custom/README.md]]
├── [[Definitions/Aspects/9 Custom/Undecile.md]]
└── [[Definitions/Aspects/9 Custom/Vadecile.md]]
```
