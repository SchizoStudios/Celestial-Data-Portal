---
tags: [INDEX, 3 Harmonic, Housekeeping]
---

```text
Definitions/Aspects/3 Harmonic
├── [[Definitions/Aspects/3 Harmonic/Biquintile.md]]
├── [[Definitions/Aspects/3 Harmonic/Decile.md]]
├── [[Definitions/Aspects/3 Harmonic/Quintile.md]]
├── [[Definitions/Aspects/3 Harmonic/README.md]]
├── [[Definitions/Aspects/3 Harmonic/Tridecile.md]]
└── [[Definitions/Aspects/3 Harmonic/Vigintile.md]]
```
