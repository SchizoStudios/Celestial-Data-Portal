---
tags: [INDEX, 5 Novile Family, Housekeeping]
---

```text
Definitions/Aspects/5 Novile Family
├── [[Definitions/Aspects/5 Novile Family/Binovile.md]]
├── [[Definitions/Aspects/5 Novile Family/Novile.md]]
├── [[Definitions/Aspects/5 Novile Family/Quadrinovile.md]]
└── [[Definitions/Aspects/5 Novile Family/README.md]]
```
