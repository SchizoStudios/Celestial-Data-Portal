---
tags: [INDEX, 6 Decile Family, Housekeeping]
---

```text
Definitions/Aspects/6 Decile Family
├── [[Definitions/Aspects/6 Decile Family/Decile.md]]
├── [[Definitions/Aspects/6 Decile Family/Quindecile.md]]
└── [[Definitions/Aspects/6 Decile Family/README.md]]
```
