---
tags: [INDEX, 2 Minor, Housekeeping]
---

```text
Definitions/Aspects/2 Minor
├── [[Definitions/Aspects/2 Minor/Inconjunction (Quincunx).md]]
├── [[Definitions/Aspects/2 Minor/Quindecile.md]]
├── [[Definitions/Aspects/2 Minor/README.md]]
├── [[Definitions/Aspects/2 Minor/Semisextile.md]]
├── [[Definitions/Aspects/2 Minor/Semisquare.md]]
└── [[Definitions/Aspects/2 Minor/Sesquiquadrate (Sesquisquare).md]]
```
