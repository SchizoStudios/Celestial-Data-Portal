Definition:

adjective

Irrevocable means not able to be changed, reversed, or undone; final.

Example Usage:

- “An irrevocable decision”
- “The initiation triggered an irrevocable shift in her path”

Etymology:

From Latin irrevocabilis, meaning “not to be recalled or undone”.

(in- = not + revocare = to call back)