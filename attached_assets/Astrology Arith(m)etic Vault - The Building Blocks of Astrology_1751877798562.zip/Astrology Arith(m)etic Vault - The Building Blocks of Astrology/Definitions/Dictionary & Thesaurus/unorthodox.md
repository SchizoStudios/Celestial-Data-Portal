# Unorthodox

# Oxford  Thesaurus of English

- 1. Unconventional
- 2. Heterodox

# Oxford Dictionary of English
## unorthodox 

### adjective
Contrary to what is usual, traditional, or accepted; not orthodox *he frequently upset other scholars with his unorthodox views*

### Derivatives
**unorthodoxly** adverb

#dictionary #Definitions 