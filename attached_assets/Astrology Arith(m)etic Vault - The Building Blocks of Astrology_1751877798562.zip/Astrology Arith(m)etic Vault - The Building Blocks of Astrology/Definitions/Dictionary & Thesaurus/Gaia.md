Definition:

Gaia is the primordial Greek Earth goddess, representing the living consciousness of Earth itself. She is both myth and metaphysical principle.

- In mythology: Gaia is the first mother, born from Chaos, who gave rise to Uranus (Sky), the Titans, and all earthly life.
- In metaphysics: Gaia refers to Earth as a conscious, evolving being—not just a planet, but a living spiritual entity with her own soul, rhythms, and ascension path.
  

Modern usage includes:

- Gaia consciousness: Awareness of ecological unity and Earth as a divine being.
- Gaian cosmology: The belief that human evolution is intertwined with Earth’s own spiritual development.