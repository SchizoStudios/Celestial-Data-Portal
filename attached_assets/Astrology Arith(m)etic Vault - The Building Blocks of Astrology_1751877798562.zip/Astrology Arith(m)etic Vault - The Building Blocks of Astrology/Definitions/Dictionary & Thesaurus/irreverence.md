# Irreverence
# New Oxford American Dictionary
## ir•rev•er•ence | ir)'rev()rens

### noun
a lack of respect for people or things that are generally taken seriously: *an attitude of irreverence toward politicians.*
