**Degree of Aspect:** (Number of Degree 0-360)
**Degree Orbs:** (Range for preferential Orb value)

**Description:**
(A description of what the aspect is and when it occurs. What this aspect represents and what attributes may be applicable to the astrology chart)

**Key Points:**
- (List of points made/presented by aspect)
- (List continued, Key Point 2)
- (Key Point 3, etc., etc.)

**Example** **(Example Interpretations)**
(Specific application example(s) for aspect.) 

**Use in Practice:**
(How to use the aspect in astrological interpretations as well as metaphysical and spiritual practice and implementation)