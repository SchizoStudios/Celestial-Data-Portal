---
tags: [INDEX, Assets, Housekeeping]
---

```text
Assets
├── [[Assets/Pasted image 20250626022617.png]]
├── [[Assets/Pasted image 20250626030359.png]]
└── [[Assets/Recording 20250626025605.m4a]]
```
