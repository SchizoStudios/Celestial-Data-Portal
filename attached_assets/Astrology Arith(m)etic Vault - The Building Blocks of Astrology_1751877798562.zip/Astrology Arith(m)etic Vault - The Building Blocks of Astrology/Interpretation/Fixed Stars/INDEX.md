---
tags: [INDEX, Fixed Stars, Housekeeping]
---

```text
Fixed Stars
├── [[Interpretation/Fixed Stars/Contra-parallels/INDEX.md]]
└── [[Interpretation/Fixed Stars/Parallels/INDEX.md]]
```
