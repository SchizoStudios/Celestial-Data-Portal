This repository's remote origin is:
https://github.com/github.com/CratingBuilds/Astrology-Arith-m-etic

To set the remote, run:
`git remote add origin https://github.com/github.com/CratingBuilds/Astrology-Arith-m-etic`

When pushing to origin, run: `git push origin main`

Credentials for pushing to the repository are stored below for convenience.
Username: CraftingBuilds
Password: <REDACTED>
