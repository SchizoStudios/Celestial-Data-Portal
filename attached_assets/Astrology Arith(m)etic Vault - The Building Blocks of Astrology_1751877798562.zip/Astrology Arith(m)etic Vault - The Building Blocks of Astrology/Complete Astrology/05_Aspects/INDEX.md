---
tags: [INDEX, 05_Aspects, Housekeeping]
---

```text
Complete Astrology/05_Aspects
├── [[Complete Astrology/05_Aspects/Aspect_Patterns_and_Configurations.md]]
├── [[Complete Astrology/05_Aspects/Major_Aspects.md]]
├── [[Complete Astrology/05_Aspects/Minor_Aspects.md]]
└── [[Complete Astrology/05_Aspects/Overview_of_Aspects.md]]
```
