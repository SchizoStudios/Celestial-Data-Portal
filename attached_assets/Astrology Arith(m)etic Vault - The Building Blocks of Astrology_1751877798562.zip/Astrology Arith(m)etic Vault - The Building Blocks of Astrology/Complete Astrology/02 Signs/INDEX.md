---
tags: [INDEX, 02 Signs, Housekeeping]
---

```text
Complete Astrology/02 Signs
├── [[Complete Astrology/02 Signs/Decanates_and_Polarities.md]]
├── [[Complete Astrology/02 Signs/Elements and Qualities.md]]
├── [[Complete Astrology/02 Signs/Overview of Signs.md]]
└── [[Complete Astrology/02 Signs/Sign Descriptions]]
    ├── [[Complete Astrology/02 Signs/Sign Descriptions/Aquarius.md]]
    ├── [[Complete Astrology/02 Signs/Sign Descriptions/Aries.md]]
    ├── [[Complete Astrology/02 Signs/Sign Descriptions/Cancer.md]]
    ├── [[Complete Astrology/02 Signs/Sign Descriptions/Capricorn.md]]
    ├── [[Complete Astrology/02 Signs/Sign Descriptions/Gemini.md]]
    ├── [[Complete Astrology/02 Signs/Sign Descriptions/Leo.md]]
    ├── [[Complete Astrology/02 Signs/Sign Descriptions/Libra.md]]
    ├── [[Complete Astrology/02 Signs/Sign Descriptions/Pisces.md]]
    ├── [[Complete Astrology/02 Signs/Sign Descriptions/Sagittarius.md]]
    ├── [[Complete Astrology/02 Signs/Sign Descriptions/Scorpio.md]]
    ├── [[Complete Astrology/02 Signs/Sign Descriptions/Taurus.md]]
    └── [[Complete Astrology/02 Signs/Sign Descriptions/Virgo.md]]
```
