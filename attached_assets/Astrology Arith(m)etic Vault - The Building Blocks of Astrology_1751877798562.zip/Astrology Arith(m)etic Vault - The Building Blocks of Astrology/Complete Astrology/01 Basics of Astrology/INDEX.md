---
tags: [INDEX, 01 Basics of Astrology, Housekeeping]
---

```text
Complete Astrology/01 Basics of Astrology
├── [[Complete Astrology/01 Basics of Astrology/History of Astrology.md]]
├── [[Complete Astrology/01 Basics of Astrology/Language of Astrology.md]]
├── [[Complete Astrology/01 Basics of Astrology/Learning Tips.md]]
└── [[Complete Astrology/01 Basics of Astrology/What Your Chart Reveals.md]]
```
