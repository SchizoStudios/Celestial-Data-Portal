---
tags: [INDEX, 04_Houses, Housekeeping]
---

```text
Complete Astrology/04_Houses
├── [[Complete Astrology/04_Houses/House_Systems.md]]
├── [[Complete Astrology/04_Houses/Individual_Houses]]
│   ├── [[Complete Astrology/04_Houses/Individual_Houses/House_1.md]]
│   ├── [[Complete Astrology/04_Houses/Individual_Houses/House_10.md]]
│   ├── [[Complete Astrology/04_Houses/Individual_Houses/House_11.md]]
│   ├── [[Complete Astrology/04_Houses/Individual_Houses/House_12.md]]
│   ├── [[Complete Astrology/04_Houses/Individual_Houses/House_2.md]]
│   ├── [[Complete Astrology/04_Houses/Individual_Houses/House_3.md]]
│   ├── [[Complete Astrology/04_Houses/Individual_Houses/House_4.md]]
│   ├── [[Complete Astrology/04_Houses/Individual_Houses/House_5.md]]
│   ├── [[Complete Astrology/04_Houses/Individual_Houses/House_6.md]]
│   ├── [[Complete Astrology/04_Houses/Individual_Houses/House_7.md]]
│   ├── [[Complete Astrology/04_Houses/Individual_Houses/House_8.md]]
│   └── [[Complete Astrology/04_Houses/Individual_Houses/House_9.md]]
├── [[Complete Astrology/04_Houses/Overview_of_Houses.md]]
└── [[Complete Astrology/04_Houses/Planets_in_Houses.md]]
```
