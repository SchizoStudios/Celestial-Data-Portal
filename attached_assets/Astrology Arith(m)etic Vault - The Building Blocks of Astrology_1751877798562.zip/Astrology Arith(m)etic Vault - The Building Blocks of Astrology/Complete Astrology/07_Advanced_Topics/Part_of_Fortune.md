# Part of Fortune

---

The **Part of Fortune** (or Lot of Fortune) is calculated using the Sun, Moon, and Ascendant. It represents a point of potential happiness or success when integrated consciously.

To find its placement, astrologers use different formulas depending on whether the chart is diurnal or nocturnal. Once located, the sign and house of the Part of Fortune can show where you may experience ease or prosperity through aligning with your natural gifts.

---

**Note:**
This file is an original educational summary for the **Astrology Arith(m)etic** project. It does **not** reproduce proprietary text.
