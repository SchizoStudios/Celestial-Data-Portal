May 2025 - Inception
June 8 2025 - Completion of folder Aspects including all subfolders and index.

June 22 2025 - Completion of Planets (Classic and Modern) in the Celestial Bodies and Calculation Points of Definitions

June 22 2025 - Completion of Dwarf Planets and Distant Bodies in the Celestial Bodies and Calculation Points folder, Subfolder of Definitions

June 26 2025 - Astrology Arith(m)etic Dedication completed and published, LICENSE created and published, landing page README created and published

June 27 2025 - Published Astrology Arith(m)etic - The Building Blocks of Astrology / Aspects as an EPUB on Apple Books and as an EPUB and Paperback on Amazon